from django import forms
from home.models import sitter

class sitterForm(forms.ModelForm):
    class Meta:
        model = sitter
        fields = '__all__'