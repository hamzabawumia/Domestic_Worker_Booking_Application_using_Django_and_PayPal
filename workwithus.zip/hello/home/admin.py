from django.contrib import admin

from .models import *

admin.site.register(Customer)
admin.site.register(Product)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(ShippingAddress)

class sitterAdmin(admin.ModelAdmin):
    list_display = ['fname','lname','email','password','address1','address2','city','state','zipc','age','gender','phone','marital_status','language','skills','anymore','pan_card','aadhar','photo']
admin.site.register(sitter,sitterAdmin)








